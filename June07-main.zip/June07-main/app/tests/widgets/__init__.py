# This file makes the 'widgets' directory a Python package.
